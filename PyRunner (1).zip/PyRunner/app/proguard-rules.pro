# Keep Chaquopy / Python related classes
-keep class com.chaquo.python.** { *; }
-keep class com.pyrunner.app.** { *; }
