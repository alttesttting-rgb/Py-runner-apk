"""
Helper module used by the Android app to execute user Python scripts
and capture stdout / stderr.
"""

import sys
import traceback
from io import StringIO


def run_code(source: str) -> str:
    """
    Execute the given Python source string.
    Returns everything that was printed (stdout + stderr) plus any exception.
    """
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    buf = StringIO()

    try:
        sys.stdout = buf
        sys.stderr = buf

        # Execute in a clean-ish global namespace
        globals_dict = {
            "__name__": "__main__",
            "__builtins__": __builtins__,
        }
        exec(compile(source, "<user_script>", "exec"), globals_dict)

    except Exception:
        # Make sure the traceback is also captured
        traceback.print_exc(file=buf)
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr

    return buf.getvalue()
