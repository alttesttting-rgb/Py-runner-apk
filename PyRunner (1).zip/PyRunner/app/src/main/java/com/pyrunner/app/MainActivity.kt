package com.pyrunner.app

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Start Python once
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(this))
        }

        setContent {
            PyRunnerTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFFFF0F5) // lavender blush
                ) {
                    PyRunnerScreen()
                }
            }
        }
    }
}

@Composable
fun PyRunnerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFFFF1493),       // deep pink
            secondary = Color(0xFFFF69B4),     // hot pink
            tertiary = Color(0xFFFFB6C1),      // light pink
            background = Color(0xFFFFF0F5),
            surface = Color(0xFFFFF0F5),
            onPrimary = Color.White,
            onSecondary = Color.White,
            onBackground = Color(0xFF4A0040),
            onSurface = Color(0xFF4A0040)
        ),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PyRunnerScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var selectedFileName by remember { mutableStateOf<String?>(null) }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var consoleText by remember { mutableStateOf("Ready.\nSelect a .py file and press Run.") }
    var isRunning by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()
    val scope = rememberCoroutineScope()
    var runJob by remember { mutableStateOf<Job?>(null) }

    // File picker launcher (Storage Access Framework – works without broad storage permission)
    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            // Get display name
            var name = "selected.py"
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex >= 0) {
                    name = cursor.getString(nameIndex) ?: name
                }
            }
            selectedFileName = name
            consoleText = "Selected: $name\nPress Run to execute."
        }
    }

    fun appendConsole(msg: String) {
        consoleText += msg
        // Auto-scroll will be handled by LaunchedEffect
    }

    fun runScript() {
        val uri = selectedUri ?: return
        if (isRunning) return

        isRunning = true
        consoleText = "=== Running ${selectedFileName ?: "script"} ===\n"

        runJob = scope.launch(Dispatchers.IO) {
            try {
                // Read the Python source
                val source = context.contentResolver.openInputStream(uri)?.use { stream ->
                    BufferedReader(InputStreamReader(stream)).readText()
                } ?: throw Exception("Could not read file")

                val py = Python.getInstance()
                val runner = py.getModule("runner")

                // Call the Python helper that executes the code and returns output
                val result = runner.callAttr("run_code", source)
                val output = result.toString()

                withContext(Dispatchers.Main) {
                    consoleText += output
                    if (!output.endsWith("\n")) consoleText += "\n"
                    consoleText += "=== Finished ===\n"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    consoleText += "\nERROR: ${e.message}\n"
                    e.printStackTrace()
                }
            } finally {
                withContext(Dispatchers.Main) {
                    isRunning = false
                }
            }
        }
    }

    fun stopScript() {
        runJob?.cancel()
        isRunning = false
        consoleText += "\n=== Stopped by user ===\n"
    }

    // Auto scroll to bottom when console changes
    LaunchedEffect(consoleText) {
        scrollState.animateScrollTo(scrollState.maxValue)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Title
        Text(
            text = "💗 Py Runner",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFFF1493),
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Text(
            text = "Works on Android & Meta Quest",
            fontSize = 13.sp,
            color = Color(0xFFC71585),
            modifier = Modifier.padding(bottom = 20.dp)
        )

        // SELECT A PY FILE button
        Button(
            onClick = {
                filePicker.launch(arrayOf("text/x-python", "text/plain", "*/*"))
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFFF1493),
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) {
            Text(
                text = "SELECT A PY FILE",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Selected file label
        Text(
            text = selectedFileName?.let { "📄 $it" } ?: "No file selected",
            color = Color(0xFF8B008B),
            fontSize = 14.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Run / Stop row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { runScript() },
                enabled = selectedUri != null && !isRunning,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFF69B4),
                    contentColor = Color.White,
                    disabledContainerColor = Color(0xFFFFC0CB)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Run", fontWeight = FontWeight.SemiBold)
            }

            Button(
                onClick = { stopScript() },
                enabled = isRunning,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDC143C),
                    contentColor = Color.White,
                    disabledContainerColor = Color(0xFFFFB6C1)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            ) {
                Icon(Icons.Default.Stop, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Stop", fontWeight = FontWeight.SemiBold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Console
        Text(
            text = "Console",
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFFC71585),
            modifier = Modifier.padding(bottom = 6.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF2D0028), RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Text(
                text = consoleText,
                color = Color(0xFFFFB6C1),
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
            )
        }
    }
}
