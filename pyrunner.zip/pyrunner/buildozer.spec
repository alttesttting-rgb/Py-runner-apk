[app]
title = Py Runner
package.name = pyrunner
package.domain = org.pyrunner
source.dir = .
source.include_exts = py,png,jpg,kv,atlas
version = 1.0

# Add pure-Python or p4a-supported packages here (e.g. requests, numpy)
requirements = python3,kivy==2.3.0,pyjnius,android

orientation = landscape
fullscreen = 0

android.permissions = READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE,MANAGE_EXTERNAL_STORAGE,INTERNET
android.api = 33
android.minapi = 29
android.ndk = 25b
android.archs = arm64-v8a
android.accept_sdk_license = True
android.allow_backup = False

[buildozer]
log_level = 2
warn_on_root = 1
