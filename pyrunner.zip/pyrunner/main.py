import ctypes
import os
import queue
import shutil
import sys
import threading
import traceback

import kivy
from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.textinput import TextInput
from kivy.utils import platform

ANDROID = platform == "android"
PICK_REQUEST = 4242
MAX_CONSOLE_CHARS = 60000


class QueueStdin:
    """Lets input() inside a script read from the app's input box."""

    def __init__(self):
        self.q = queue.Queue()

    def readline(self, *_):
        return self.q.get()

    def read(self, *_):
        return self.q.get()

    def feed(self, text):
        self.q.put(text)

    def isatty(self):
        return False


class UIWriter:
    """Replaces sys.stdout / sys.stderr and forwards text to the console."""

    def __init__(self, sink):
        self.sink = sink

    def write(self, s):
        if s:
            Clock.schedule_once(lambda dt, s=s: self.sink(s))
        return len(s)

    def flush(self):
        pass

    def isatty(self):
        return False


class PyRunnerApp(App):
    title = "Py Runner"

    def build(self):
        self.script_path = None
        self.worker = None
        self.stdin = QueueStdin()
        self.last_dir = None

        mono = os.path.join(kivy.kivy_data_dir, "fonts", "RobotoMono-Regular.ttf")
        font = mono if os.path.exists(mono) else "Roboto"
        bh = dp(56)
        fs = dp(18)

        root = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(8))

        bar = BoxLayout(size_hint_y=None, height=bh, spacing=dp(8))
        self.btn_select = Button(text="Select .py file", font_size=fs)
        self.btn_select.bind(on_release=self.open_picker)
        self.btn_run = Button(text="Run", font_size=fs, size_hint_x=0.4)
        self.btn_run.bind(on_release=lambda *_: self.run_script())
        self.btn_stop = Button(text="Stop", font_size=fs, size_hint_x=0.4)
        self.btn_stop.bind(on_release=lambda *_: self.stop_script())
        self.btn_clear = Button(text="Clear", font_size=fs, size_hint_x=0.4)
        self.btn_clear.bind(on_release=lambda *_: setattr(self.console, "text", ""))
        for b in (self.btn_select, self.btn_run, self.btn_stop, self.btn_clear):
            bar.add_widget(b)
        root.add_widget(bar)

        self.lbl_file = Label(
            text="No file selected", size_hint_y=None, height=dp(32),
            font_size=dp(15), halign="left", valign="middle", shorten=True,
            shorten_from="left",
        )
        self.lbl_file.bind(size=lambda w, s: setattr(w, "text_size", s))
        root.add_widget(self.lbl_file)

        self.console = TextInput(
            readonly=True, font_name=font, font_size=dp(15),
            background_color=(0.07, 0.07, 0.09, 1),
            foreground_color=(0.9, 0.95, 0.9, 1),
        )
        root.add_widget(self.console)

        inp = BoxLayout(size_hint_y=None, height=bh, spacing=dp(8))
        self.input_box = TextInput(
            multiline=False, hint_text="Input for input() ...",
            font_size=fs, write_tab=False,
        )
        self.input_box.bind(on_text_validate=self.send_input)
        btn_send = Button(text="Send", font_size=fs, size_hint_x=0.25)
        btn_send.bind(on_release=self.send_input)
        inp.add_widget(self.input_box)
        inp.add_widget(btn_send)
        root.add_widget(inp)
        return root

    def on_start(self):
        os.makedirs(self.scripts_dir(), exist_ok=True)
        if ANDROID:
            try:
                from android.permissions import Permission, request_permissions
                request_permissions([
                    Permission.READ_EXTERNAL_STORAGE,
                    Permission.WRITE_EXTERNAL_STORAGE,
                ])
            except Exception:
                traceback.print_exc()
        self.append("Tap 'Select .py file', pick a script, then press Run.\n")

    # ---------- folders ----------
    def scripts_dir(self):
        """Folder reachable via adb push on Android (no permission needed)."""
        if ANDROID:
            try:
                from jnius import autoclass
                act = autoclass("org.kivy.android.PythonActivity").mActivity
                d = act.getExternalFilesDir(None)
                if d is not None:
                    return os.path.join(d.getAbsolutePath(), "scripts")
            except Exception:
                pass
        return os.path.join(self.user_data_dir, "scripts")

    def storage_root(self):
        return "/storage/emulated/0" if ANDROID else os.path.expanduser("~")

    # ---------- console ----------
    def append(self, text):
        t = self.console.text + text
        if len(t) > MAX_CONSOLE_CHARS:
            t = t[-MAX_CONSOLE_CHARS:]
        self.console.text = t
        Clock.schedule_once(
            lambda dt: self.console.do_cursor_movement("cursor_end", control=True), 0
        )

    def send_input(self, *_):
        self.append(self.input_box.text + "\n")
        self.stdin.feed(self.input_box.text + "\n")
        self.input_box.text = ""
        Clock.schedule_once(lambda dt: setattr(self.input_box, "focus", True), 0.1)

    # ---------- file picker ----------
    def open_picker(self, *_):
        start = self.last_dir or self.scripts_dir()
        if not os.path.isdir(start) or not os.access(start, os.R_OK):
            start = self.scripts_dir()

        content = BoxLayout(orientation="vertical", spacing=dp(6))

        shortcuts = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(6))
        chooser = FileChooserListView(path=start, filters=["*.py"], dirselect=False)

        def go(path):
            if os.path.isdir(path) and os.access(path, os.R_OK):
                chooser.path = path
            else:
                self.append("Cannot open %s (no access)\n" % path)

        def add_shortcut(text, fn):
            b = Button(text=text, font_size=dp(14))
            b.bind(on_release=lambda *_: fn())
            shortcuts.add_widget(b)

        add_shortcut("App folder", lambda: go(self.scripts_dir()))
        add_shortcut("Storage", lambda: go(self.storage_root()))
        add_shortcut("Download", lambda: go(os.path.join(self.storage_root(), "Download")))
        if ANDROID:
            add_shortcut("All-files access", self.request_all_files)
            add_shortcut("System picker", lambda: (popup.dismiss(), self.open_system_picker()))

        content.add_widget(shortcuts)
        content.add_widget(chooser)

        actions = BoxLayout(size_hint_y=None, height=dp(56), spacing=dp(8))
        btn_cancel = Button(text="Cancel", font_size=dp(18))
        btn_open = Button(text="Open", font_size=dp(18))
        actions.add_widget(btn_cancel)
        actions.add_widget(btn_open)
        content.add_widget(actions)

        popup = Popup(title="Select a .py file", content=content, size_hint=(0.95, 0.92))

        def choose(*_):
            if chooser.selection:
                path = chooser.selection[0]
                self.last_dir = os.path.dirname(path)
                popup.dismiss()
                self.set_script(path)

        btn_cancel.bind(on_release=popup.dismiss)
        btn_open.bind(on_release=choose)
        chooser.bind(on_submit=lambda inst, sel, touch: choose())
        popup.open()

    def set_script(self, path):
        self.script_path = path
        self.lbl_file.text = path
        self.append("Selected: %s\n" % path)

    # ---------- Android-only helpers ----------
    def request_all_files(self):
        try:
            from jnius import autoclass
            Build = autoclass("android.os.Build$VERSION")
            Env = autoclass("android.os.Environment")
            if Build.SDK_INT >= 30 and not Env.isExternalStorageManager():
                Intent = autoclass("android.content.Intent")
                Settings = autoclass("android.provider.Settings")
                Uri = autoclass("android.net.Uri")
                act = autoclass("org.kivy.android.PythonActivity").mActivity
                uri = Uri.parse("package:" + act.getPackageName())
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, uri)
                )
            else:
                self.append("All-files access already granted (or not needed).\n")
        except Exception:
            self.append("Could not open all-files settings:\n" + traceback.format_exc())

    def open_system_picker(self):
        try:
            from android import activity
            from jnius import autoclass
            Intent = autoclass("android.content.Intent")
            act = autoclass("org.kivy.android.PythonActivity").mActivity
            intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
            intent.addCategory(Intent.CATEGORY_OPENABLE)
            intent.setType("*/*")
            activity.bind(on_activity_result=self._on_activity_result)
            act.startActivityForResult(intent, PICK_REQUEST)
        except Exception:
            self.append("System picker unavailable:\n" + traceback.format_exc())

    def _on_activity_result(self, request_code, result_code, intent):
        if request_code != PICK_REQUEST:
            return
        try:
            from android import activity
            activity.unbind(on_activity_result=self._on_activity_result)
        except Exception:
            pass
        if result_code != -1 or intent is None:  # RESULT_OK == -1
            return
        try:
            from jnius import autoclass
            OpenableColumns = autoclass("android.provider.OpenableColumns")
            act = autoclass("org.kivy.android.PythonActivity").mActivity
            resolver = act.getContentResolver()
            uri = intent.getData()

            name = "picked.py"
            cursor = resolver.query(uri, None, None, None, None)
            if cursor is not None:
                try:
                    idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if idx >= 0 and cursor.moveToFirst():
                        name = cursor.getString(idx) or name
                finally:
                    cursor.close()

            pfd = resolver.openFileDescriptor(uri, "r")
            fd = pfd.detachFd()
            dest_dir = os.path.join(self.user_data_dir, "picked")
            os.makedirs(dest_dir, exist_ok=True)
            dest = os.path.join(dest_dir, os.path.basename(name))
            with os.fdopen(fd, "rb") as src, open(dest, "wb") as out:
                shutil.copyfileobj(src, out)
            Clock.schedule_once(lambda dt: self.set_script(dest))
        except Exception:
            tb = traceback.format_exc()
            Clock.schedule_once(lambda dt: self.append("Pick failed:\n" + tb))

    # ---------- running ----------
    def run_script(self):
        if not self.script_path:
            self.append("Select a .py file first.\n")
            return
        if self.worker and self.worker.is_alive():
            self.append("A script is already running. Press Stop first.\n")
            return
        self.append("\n--- running %s ---\n" % os.path.basename(self.script_path))
        self.worker = threading.Thread(
            target=self._worker, args=(self.script_path,), daemon=True
        )
        self.worker.start()

    def _worker(self, path):
        old_streams = (sys.stdout, sys.stderr, sys.stdin)
        old_path = list(sys.path)
        sys.stdout = sys.stderr = UIWriter(self.append)
        sys.stdin = self.stdin
        sys.path.insert(0, os.path.dirname(path))
        try:
            with open(path, "r", encoding="utf-8") as f:
                src = f.read()
            g = {"__name__": "__main__", "__file__": path, "__builtins__": __builtins__}
            exec(compile(src, path, "exec"), g)
            print("\n[finished]")
        except SystemExit as e:
            print("\n[exited: %s]" % (e.code,))
        except KeyboardInterrupt:
            print("\n[stopped]")
        except BaseException:
            traceback.print_exc()
        finally:
            sys.stdout, sys.stderr, sys.stdin = old_streams
            sys.path[:] = old_path

    def stop_script(self):
        t = self.worker
        if t and t.is_alive():
            ctypes.pythonapi.PyThreadState_SetAsyncExc(
                ctypes.c_ulong(t.ident), ctypes.py_object(KeyboardInterrupt)
            )
            self.stdin.feed("\n")  # unblock a pending input()


if __name__ == "__main__":
    PyRunnerApp().run()
