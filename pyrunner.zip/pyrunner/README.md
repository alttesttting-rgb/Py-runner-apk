# Py Runner

A small Kivy app that runs Python scripts on Android phones and on Android-based VR headsets (as a 2D panel app).

- **Select .py file** button: built-in file browser, plus the Android system picker where available
- **Run / Stop / Clear**, live console output, and an input box for `input()`

## Build the APK (no Linux needed)

1. Create a new GitHub repo and upload everything in this folder (including `.github/`).
2. Open the **Actions** tab, run **Build APK** (it also runs on every push).
3. When it finishes (about 15-30 min the first time), download the `pyrunner-apk` artifact and unzip it.

Local build (Linux or WSL): `pip install buildozer`, then `buildozer android debug`. The APK lands in `bin/`.

## Install

- **Android phone:** copy the APK over and open it (allow "install unknown apps").
- **VR headset:** `adb install pyrunner-*.apk`, or use a sideloading tool such as Meta Quest Developer Hub. Launch it from the library under **Unknown Sources**.

## Getting scripts onto the device

- Easiest, no permissions: push into the app folder
  `adb push myscript.py /sdcard/Android/data/org.pyrunner.pyrunner/files/scripts/`
  then tap **Select .py file** > **App folder**.
- Or put scripts in `Download` and use the **Download** / **All-files access** buttons.
- On phones, **System picker** works too.

## Limits

- Scripts run inside the app's Python, so only packages listed in `requirements` in `buildozer.spec` are available (add e.g. `requests`, `numpy`).
- Console and text only: scripts that open their own windows (tkinter, pygame, etc.) won't work.
- It is a flat panel app, not an immersive VR app.
